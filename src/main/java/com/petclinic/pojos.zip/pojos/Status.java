package com.petclinic.pojos;

public enum Status {
 PENDING,APPROVED,COMPLETED
}
