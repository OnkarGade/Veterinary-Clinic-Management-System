package com.petclinic.pojos;
import java.util.List;

import jakarta.persistence.*;
import lombok.*;
@Entity
@Table(name="receptionists")
@Getter
@Setter
@NoArgsConstructor
public class Receptionist extends BaseEntity{
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="recep_id",unique = true,nullable = false)
	private User receptionist;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "receptionist")
	private List<Appointment> appointments;
	
	
	@Column(length =20)
	private String qualification;
	
	@Column(name= "aadhar_no",length =12)
	private String aadharNo;
	
	public Receptionist(User u) {
		receptionist=u;
	}

	public void addAppoint(Appointment appoint) {
		appointments.add(appoint);
		appoint.setReceptionist(this);
		
	}
	
	
}
