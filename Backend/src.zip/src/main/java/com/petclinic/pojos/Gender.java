package com.petclinic.pojos;

public enum Gender {
MALE,FEMALE,OTHER
}
