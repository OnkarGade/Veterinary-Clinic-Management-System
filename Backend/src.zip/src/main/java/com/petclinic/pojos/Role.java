package com.petclinic.pojos;

public enum Role {
  PETOWNER,DOCTOR,RECEPTIONIST,ADMIN
}
