//package com.petclinic.service;
//
//import com.petclinic.dto.ApiResponse;
//import com.petclinic.dto.StaffReqDto;
//
//public interface AdminService {
//
//	public ApiResponse RegStaff(StaffReqDto sReqDto);
//
//}
